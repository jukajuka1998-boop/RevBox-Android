# RevBox Android wrapper

This project packages the original RevBox HTML interface in an Android WebView.
The original HTML asset is kept as `app/src/main/assets/index.html` without editing its UI/audio data.

## Build
GitHub Actions runs `gradle assembleDebug` on pushes to `main` or via manual workflow dispatch.
The APK is uploaded as the `RevBox-debug-apk` workflow artifact.

Note: this initial wrapper does not yet implement native Bluetooth OBD-II or a native Wi-Fi TCP-to-WebSocket bridge. The original HTML's existing OBD bridge behavior is preserved; adapter integration needs a separate implementation and device testing.
